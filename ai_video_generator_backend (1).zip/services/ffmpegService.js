const ffmpeg = require('fluent-ffmpeg');
const path = require('path');

exports.renderVideo = async (scenePaths, audioPaths) => {
  const outputPath = path.join(__dirname, '../../output/final-video.mp4');

  return new Promise((resolve, reject) => {
    const command = ffmpeg();
    scenePaths.forEach((scene) => command.input(scene));
    command
      .on('end', () => resolve(outputPath))
      .on('error', reject)
      .mergeToFile(outputPath);
  });
};