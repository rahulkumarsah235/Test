const axios = require('axios');
const fs = require('fs');
const path = require('path');

exports.generateVoice = async (name, text, gender, mood) => {
  const voice_id = 'YOUR_VOICE_ID';

  const response = await axios.post(
    `https://api.elevenlabs.io/v1/text-to-speech/${voice_id}`,
    { text, voice_settings: { stability: 0.75, similarity_boost: 0.8 } },
    {
      headers: {
        'xi-api-key': process.env.ELEVENLABS_API_KEY,
        'Content-Type': 'application/json',
      },
      responseType: 'stream',
    }
  );

  const filePath = path.join(__dirname, `../../output/audio/${name}-${Date.now()}.mp3`);
  await new Promise((resolve, reject) => {
    const stream = fs.createWriteStream(filePath);
    response.data.pipe(stream);
    stream.on('finish', resolve);
    stream.on('error', reject);
  });

  return filePath;
};