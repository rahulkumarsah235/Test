const path = require('path');
exports.generateScene = async (description, style) => {
  const dummyVideo = path.join(__dirname, '../../assets/sample-scene.mp4');
  return dummyVideo;
};