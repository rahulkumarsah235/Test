const { Configuration, OpenAIApi } = require('openai');
const config = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
const openai = new OpenAIApi(config);

exports.parseScript = async (scriptText) => {
  const prompt = `Analyze this script and extract:
  1. Characters (name, gender, mood),
  2. Scene background,
  3. Sound effects,
  4. Camera hints.
Script:\n\n${scriptText}`;

  const completion = await openai.createChatCompletion({
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
  });

  return JSON.parse(completion.data.choices[0].message.content);
};