const express = require('express');
const router = express.Router();
const { generateVoice } = require('../services/elevenLabsService');

router.post('/', async (req, res) => {
  try {
    const { characterName, text, gender, mood } = req.body;
    const audioUrl = await generateVoice(characterName, text, gender, mood);
    res.json({ audioUrl });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;