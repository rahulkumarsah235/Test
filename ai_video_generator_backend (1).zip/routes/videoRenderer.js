const express = require('express');
const router = express.Router();
const { renderVideo } = require('../services/ffmpegService');

router.post('/', async (req, res) => {
  try {
    const { scenes, audioTracks } = req.body;
    const videoPath = await renderVideo(scenes, audioTracks);
    res.download(videoPath);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;