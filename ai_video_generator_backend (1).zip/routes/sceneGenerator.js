const express = require('express');
const router = express.Router();
const { generateScene } = require('../services/sceneService');

router.post('/', async (req, res) => {
  try {
    const { sceneDescription, style } = req.body;
    const scenePath = await generateScene(sceneDescription, style);
    res.json({ scenePath });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;