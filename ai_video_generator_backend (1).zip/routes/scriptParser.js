const express = require('express');
const router = express.Router();
const { parseScript } = require('../services/gptService');

router.post('/', async (req, res) => {
  try {
    const { script } = req.body;
    const parsed = await parseScript(script);
    res.json(parsed);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;